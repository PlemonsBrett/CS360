package io.plemons.inventoryapp_brettplemons.activities;

import static io.plemons.inventoryapp_brettplemons.utility.Helpers.hideKeyboard;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import io.plemons.inventoryapp_brettplemons.R;
import io.plemons.inventoryapp_brettplemons.database.DatabaseHelper;
import io.plemons.inventoryapp_brettplemons.utility.InventoryCheckService;

public class MainActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DatabaseHelper(this);

        if (isLoggedIn()) {
            startInventoryCheckService();
            redirectToInventoryActivity();
        } else {
            initializeLoginUI();
        }
    }

    private void startInventoryCheckService() {
        Intent serviceIntent = new Intent(this, InventoryCheckService.class);
        startService(serviceIntent);
    }

    private void redirectToInventoryActivity() {
        Intent intent = new Intent(this, InventoryActivity.class);
        startActivity(intent);
        finish(); // Close MainActivity
    }

    private void initializeLoginUI() {
        final EditText usernameEditText = findViewById(R.id.username);
        final EditText passwordEditText = findViewById(R.id.password);
        Button loginButton = findViewById(R.id.login);
        Button createAccountButton = findViewById(R.id.create_account);

        setupTouchListeners();
        setupEditorActionListeners(usernameEditText, passwordEditText);
        setupLoginButtonListener(usernameEditText, passwordEditText, loginButton);
        setupCreateAccountButtonListener(createAccountButton);
    }

    private void setupTouchListeners() {
        findViewById(R.id.parent_layout).setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_UP) {
                v.performClick();
            }
            hideKeyboard(this);
            return true;
        });
    }

    private boolean focusNextField(EditText nextField) {
        nextField.requestFocus();
        return true;
    }

    private void setupEditorActionListeners(EditText usernameEditText, EditText passwordEditText) {
        // Change focus to the next field when "enter" key is pressed
        usernameEditText.setOnEditorActionListener((v, actionId, event) -> actionId == EditorInfo.IME_ACTION_NEXT && focusNextField(passwordEditText));

        // Close keyboard when "enter" key is pressed
        passwordEditText.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                hideKeyboard(this);
                return true; // Return true to indicate that the action was handled
            }
            return false; // Return false if the action was not handled
        });
    }

    private void setupLoginButtonListener(EditText usernameEditText, EditText passwordEditText, Button loginButton) {
        loginButton.setOnClickListener(v -> {
            String email = usernameEditText.getText().toString();
            String password = passwordEditText.getText().toString();

            if (dbHelper.validateUser(email, password)) {
                login(email);
                redirectToInventoryActivity();
            } else {
                passwordEditText.setError("Invalid Credentials. If you do not have an account, create a new one.");
            }
        });
    }

    private void setupCreateAccountButtonListener(Button createAccountButton) {
        createAccountButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, RegistrationActivity.class);
            startActivity(intent);
        });
    }

    private void login(String email) {
        sharedPreferences = getSharedPreferences("InventoryApp", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("email", email);
        editor.apply();
    }

    public boolean isLoggedIn() {
        sharedPreferences = getSharedPreferences("InventoryApp", MODE_PRIVATE);
        return sharedPreferences.contains("email");
    }
}
