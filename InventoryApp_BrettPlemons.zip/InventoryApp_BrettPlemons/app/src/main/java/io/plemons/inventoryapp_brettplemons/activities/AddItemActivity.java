package io.plemons.inventoryapp_brettplemons.activities;

import static io.plemons.inventoryapp_brettplemons.utility.Helpers.hideKeyboard;

import android.os.Bundle;
import android.view.MotionEvent;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Objects;

import io.plemons.inventoryapp_brettplemons.models.InventoryItem;
import io.plemons.inventoryapp_brettplemons.R;
import io.plemons.inventoryapp_brettplemons.models.User;
import io.plemons.inventoryapp_brettplemons.database.DatabaseHelper;

public class AddItemActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_item_form);

        // Initialize DatabaseHelper
        dbHelper = createDatabaseHelper();

        // Retrieve user information
        String email = getIntent().getStringExtra("email");
        User user = dbHelper.getUser(email);

        // Hide keyboard on touch outside input fields
        findViewById(R.id.add_item_form).setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_UP) {
                v.performClick();
            }
            hideKeyboard(this);
            return true;
        });

        // Initialize views
        TextInputEditText itemIdEditText = findViewById(R.id.item_id);
        TextInputEditText itemNameEditText = findViewById(R.id.item_name);
        TextInputEditText itemDescriptionEditText = findViewById(R.id.item_description);
        TextInputEditText quantityEditText = findViewById(R.id.quantity);
        TextInputEditText unitEditText = findViewById(R.id.unit);
        TextInputEditText locationEditText = findViewById(R.id.location);
        MaterialButton addItemButton = findViewById(R.id.add_item_button);

        // Handle add item button click
        addItemButton.setOnClickListener(v -> {
            // Retrieve input values
            String itemId = Objects.requireNonNull(itemIdEditText.getText()).toString();
            String itemName = Objects.requireNonNull(itemNameEditText.getText()).toString();
            String itemDescription = Objects.requireNonNull(itemDescriptionEditText.getText()).toString();
            int quantity = Integer.parseInt(Objects.requireNonNull(quantityEditText.getText()).toString());
            String unit = Objects.requireNonNull(unitEditText.getText()).toString();
            String location = Objects.requireNonNull(locationEditText.getText()).toString();
            int createdBy = user.getId();
            String currentDateTime = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());

            // Create a new InventoryItem object
            InventoryItem newItem = new InventoryItem(itemId, itemName, itemDescription, quantity, unit, location, createdBy, currentDateTime, createdBy);

            // Check if the ItemID already exists
            if (dbHelper.itemExists(itemId)) {
                // Show an error message
                itemIdEditText.setError("An item with this ID already exists.");
                return;
            } else {
                itemIdEditText.setError(null);
            }

            // Add the item to the database if no errors
            if (itemIdEditText.getError() == null) {
                dbHelper.insertItem(newItem);
                Toast.makeText(this, "Item added successfully!", Toast.LENGTH_SHORT).show();
                finish();
            }
        });
    }

    // Method to create DatabaseHelper instance
    DatabaseHelper createDatabaseHelper() {
        return new DatabaseHelper(this);
    }
}
