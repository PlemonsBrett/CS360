package io.plemons.inventoryapp_brettplemons.activities;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.material.switchmaterial.SwitchMaterial;

import io.plemons.inventoryapp_brettplemons.R;
import io.plemons.inventoryapp_brettplemons.database.DatabaseHelper;
import io.plemons.inventoryapp_brettplemons.models.User;

public class SettingsActivity extends AppCompatActivity {
    private boolean isEditing = false;
    private SharedPreferences sharedPreferences;
    private DatabaseHelper dbHelper;
    private User user;

    // Declare views
    private EditText userIdEditText, firstNameEditText, lastNameEditText, emailEditText, phoneEditText;
    private SwitchMaterial smsConsentSwitch;
    private Button editButton;
    private EditText inventoryCheckFrequencyEditText;
    private static final int REQUEST_CODE_SMS_PERMISSION = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        // Initialize views
        userIdEditText = findViewById(R.id.user_id);
        firstNameEditText = findViewById(R.id.first_name);
        lastNameEditText = findViewById(R.id.last_name);
        emailEditText = findViewById(R.id.email);
        phoneEditText = findViewById(R.id.phone);
        smsConsentSwitch = findViewById(R.id.notification_toggle);
        editButton = findViewById(R.id.edit_button);
        Button logoutButton = findViewById(R.id.logout_button);
        Button backButton = findViewById(R.id.back_button);
        inventoryCheckFrequencyEditText = findViewById(R.id.inventory_check_frequency);

        // Initialize SharedPreferences
        sharedPreferences = getSharedPreferences("InventoryApp", Context.MODE_PRIVATE);

        // Initialize DatabaseHelper
        dbHelper = new DatabaseHelper(this);

        // Load user information
        user = loadUserInfo();

        // Populate EditText fields
        userIdEditText.setText(String.valueOf(user.getId()));
        firstNameEditText.setText(user.getFirstName());
        lastNameEditText.setText(user.getLastName());
        emailEditText.setText(user.getEmail());
        phoneEditText.setText(user.getPhone());
        smsConsentSwitch.setChecked(user.getSmsConsent());

        // Load inventory check frequency
        inventoryCheckFrequencyEditText.setText(sharedPreferences.getString("inv_check_freq", "5"));

        // Handle SMS consent switch
        smsConsentSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                // If the switch is enabled and permission is not granted, request permission
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, REQUEST_CODE_SMS_PERMISSION);
                }
            } else {
                // If the switch is disabled and permission is granted, guide the user to revoke it
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
                    new AlertDialog.Builder(this)
                            .setTitle("Revoke SMS Permission")
                            .setMessage("To revoke the SMS permission, please go to the system settings.")
                            .setPositiveButton("Go to Settings", (dialog, which) -> {
                                Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                                Uri uri = Uri.fromParts("package", getPackageName(), null);
                                intent.setData(uri);
                                startActivity(intent);
                            })
                            .setNegativeButton("Cancel", null)
                            .show();
                }
            }
        });

        // Edit button click listener
        editButton.setOnClickListener(v -> {
            if (firstNameEditText.isFocusable()) {
                // Switch to non-editable mode
                setEditable(false);
                editButton.setText(R.string.edit_button_text);
            } else {
                // Switch to editable mode
                setEditable(true);
                editButton.setText(R.string.cancel_button_text);
            }
        });

        // Save button click listener
        findViewById(R.id.save_button).setOnClickListener(v -> {
            if (isEditing) {
                // Save changes
                saveUserInfo();
                sharedPreferences.edit().putString("inv_check_freq", inventoryCheckFrequencyEditText.getText().toString()).apply();
                isEditing = false;
                editButton.setText(R.string.edit_button_text);
                setEditable(false);
            }
        });

        // Delete account button click listener
        findViewById(R.id.delete_account_button).setOnClickListener(v -> new AlertDialog.Builder(SettingsActivity.this)
                .setTitle("Delete Account")
                .setMessage("Are you sure you want to delete your account?")
                .setPositiveButton(android.R.string.yes, (dialog, which) -> {
                    dbHelper.deleteUser(userIdEditText.getText().toString());
                    sharedPreferences.edit().clear().apply();
                    Intent intent = new Intent(SettingsActivity.this, MainActivity.class);
                    startActivity(intent);
                    finish();
                })
                .setNegativeButton(android.R.string.no, null)
                .setIcon(android.R.drawable.ic_dialog_alert)
                .show()
        );

        // Logout button click listener
        logoutButton.setOnClickListener(v -> {
            // Clear SharedPreferences
            SharedPreferences sharedPreferences = getSharedPreferences("InventoryApp", Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.clear();
            editor.apply();

            // Navigate to MainActivity
            Intent intent = new Intent(SettingsActivity.this, MainActivity.class);
            startActivity(intent);

            // Finish current activity
            finish();
        });

        // Back button click listener
        backButton.setOnClickListener(v -> finish());
    }

    private User loadUserInfo() {
        String email = sharedPreferences.getString("email", null);
        return dbHelper.getUser(email);
    }

    private void saveUserInfo() {
        user.setFirstName(firstNameEditText.getText().toString());
        user.setLastName(lastNameEditText.getText().toString());
        user.setEmail(emailEditText.getText().toString());
        user.setPhone(phoneEditText.getText().toString());
        user.setSmsConsent(smsConsentSwitch.isChecked());
        if (dbHelper.updateUser(user)) {
            Toast.makeText(this, "Your information was successfully updated!", Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(this, "There was an error while updating your info, try again or restart the app.", Toast.LENGTH_LONG).show();
        }
    }

    private void setEditable(boolean editable) {
        firstNameEditText.setEnabled(editable);
        lastNameEditText.setEnabled(editable);
        emailEditText.setEnabled(editable);
        phoneEditText.setEnabled(editable);
        smsConsentSwitch.setEnabled(editable);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CODE_SMS_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission was granted
                smsConsentSwitch.setChecked(true);
            } else {
                // Permission was denied
                smsConsentSwitch.setChecked(false);
                Toast.makeText(this, "SMS permission is required to enable notifications.", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
