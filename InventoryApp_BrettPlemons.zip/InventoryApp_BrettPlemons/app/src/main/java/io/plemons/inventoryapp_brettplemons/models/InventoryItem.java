package io.plemons.inventoryapp_brettplemons.models;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class InventoryItem implements Serializable {

    private final String itemId;
    private String itemName;
    private String itemDescription;
    private int quantity;
    private String unit;
    private String location;
    private final int createdBy;
    private String lastUpdated;
    private int lastUpdatedBy;

    public InventoryItem(
            String itemId,
            String itemName,
            String itemDescription,
            int quantity,
            String unit,
            String location,
            int createdBy,
            String lastUpdated,
            int lastUpdatedBy
    ) {
        this.itemId = itemId;
        this.itemName = itemName;
        this.itemDescription = itemDescription;
        this.quantity = quantity;
        this.unit = unit;
        this.location = location;
        this.createdBy = createdBy;
        this.lastUpdated = lastUpdated;
        this.lastUpdatedBy = lastUpdatedBy;
    }

    public String getItemId() {
        return this.itemId;
    }

    public String getItemName() {
        return this.itemName;
    }

    public String getItemDescription() {
        return this.itemDescription;
    }

    public int getQuantity() {
        return this.quantity;
    }

    public String getUnit() {
        return this.unit;
    }

    public String getLocation() {
        return this.location;
    }

    public int getCreatedBy() { return this.createdBy; }

    public String getLastUpdated() {
        return this.lastUpdated;
    }
    public int getLastUpdatedBy() { return this.lastUpdatedBy; }

    // Setters
    public void setItemName(String updatedName) {
        this.itemName = updatedName;
    }
    public void setItemDescription(String description) {
        this.itemDescription = description;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public void setLastUpdated() {
        this.lastUpdated = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
    }

    public void setLastUpdatedBy(int userId) {
        this.lastUpdatedBy = userId;
    }
}
