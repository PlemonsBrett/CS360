package io.plemons.inventoryapp_brettplemons.activities;

import static io.plemons.inventoryapp_brettplemons.utility.Helpers.hideKeyboard;

import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Objects;

import io.plemons.inventoryapp_brettplemons.models.InventoryItem;
import io.plemons.inventoryapp_brettplemons.R;
import io.plemons.inventoryapp_brettplemons.models.User;
import io.plemons.inventoryapp_brettplemons.database.DatabaseHelper;

public class EditItemActivity extends AppCompatActivity {

    private InventoryItem currentItem; // The item being edited
    private User user;

    // Initialize class variables
    TextInputEditText itemIdEditText, itemNameEditText, itemDescriptionEditText, quantityEditText,
            unitEditText, locationEditText, createdByEditText, lastUpdatedEditText, lastUpdatedByEditText;
    MaterialButton saveButton, cancelButton, deleteButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.edit_item_form);

        DatabaseHelper dbHelper = new DatabaseHelper(this);

        // Retrieve the item ID and user email
        String id = getIntent().getStringExtra("itemId");
        String email = getIntent().getStringExtra("email");

        // Fetch the item and user from the database
        currentItem = dbHelper.getItem(id);
        if (email != null) {
            user = dbHelper.getUser(email);
        } else {
            Log.d("EditItemActivity", "email is null");
            finish();
        }

        // Hide keyboard on touch outside input fields
        findViewById(R.id.edit_item_form).setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_UP) {
                v.performClick();
            }
            hideKeyboard(this);
            return true;
        });

        // Initialize views
        initializeViews();

        // Populate the fields with the current item's data
        populateFields();

        // Set up button click listeners
        setupButtons(dbHelper);
    }

    private void initializeViews() {
        // Find the views
        itemIdEditText = findViewById(R.id.item_id);
        itemNameEditText = findViewById(R.id.item_name);
        itemDescriptionEditText = findViewById(R.id.item_description);
        quantityEditText = findViewById(R.id.quantity);
        unitEditText = findViewById(R.id.unit);
        locationEditText = findViewById(R.id.location);
        createdByEditText = findViewById(R.id.created_by);
        lastUpdatedEditText = findViewById(R.id.last_updated);
        lastUpdatedByEditText = findViewById(R.id.last_updated_by);
        saveButton = findViewById(R.id.save_button);
        cancelButton = findViewById(R.id.cancel_button);
        deleteButton = findViewById(R.id.delete_button);
    }

    private void populateFields() {
        // Populate the fields with the current item's data
        itemIdEditText.setText(String.valueOf(currentItem.getItemId()));
        itemNameEditText.setText(String.valueOf(currentItem.getItemName()));
        itemDescriptionEditText.setText(String.valueOf(currentItem.getItemDescription()));
        quantityEditText.setText(String.valueOf(currentItem.getQuantity()));
        unitEditText.setText(String.valueOf(currentItem.getUnit()));
        locationEditText.setText(String.valueOf(currentItem.getLocation()));
        createdByEditText.setText(String.valueOf(currentItem.getCreatedBy()));
        lastUpdatedEditText.setText(String.valueOf(currentItem.getLastUpdated()));
        lastUpdatedByEditText.setText(String.valueOf(currentItem.getLastUpdatedBy()));
    }

    private void setupButtons(DatabaseHelper dbHelper) {
        // Set up the save button click listener
        saveButton.setOnClickListener(v -> {
            // Retrieve the updated values
            updateItem(dbHelper);

            Toast.makeText(this, "Item updated successfully!", Toast.LENGTH_SHORT).show();

            // Close the activity
            finish();
        });

        cancelButton.setOnClickListener(v -> {
            // Stop editing
            finish();
        });

        // Set up the delete button click listener
        deleteButton.setOnClickListener(v -> {
            // Delete the item from the database
            dbHelper.deleteItem(currentItem.getItemId());

            Toast.makeText(this, "Item deleted successfully!", Toast.LENGTH_SHORT).show();

            // Close the activity
            finish();
        });
    }

    private void updateItem(DatabaseHelper dbHelper) {
        // Retrieve the updated values
        String itemId = Objects.requireNonNull(itemIdEditText.getText()).toString();
        String itemName = Objects.requireNonNull(itemNameEditText.getText()).toString();
        String itemDescription = Objects.requireNonNull(itemDescriptionEditText.getText()).toString();
        int quantity = Integer.parseInt(Objects.requireNonNull(quantityEditText.getText()).toString());
        String unit = Objects.requireNonNull(unitEditText.getText()).toString();
        String location = Objects.requireNonNull(locationEditText.getText()).toString();
        int createdBy = Integer.parseInt(Objects.requireNonNull(createdByEditText.getText()).toString());
        String lastUpdated = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
        int lastUpdatedBy = user.getId();

        // Update the current item object
        currentItem = new InventoryItem(itemId, itemName, itemDescription, quantity, unit, location, createdBy, lastUpdated, lastUpdatedBy);

        // Update the item in the database
        dbHelper.updateItem(currentItem);
    }
}
