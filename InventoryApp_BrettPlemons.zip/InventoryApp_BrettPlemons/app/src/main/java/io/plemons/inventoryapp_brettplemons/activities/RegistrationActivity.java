package io.plemons.inventoryapp_brettplemons.activities;

        import static io.plemons.inventoryapp_brettplemons.utility.Helpers.hideKeyboard;

        import android.Manifest;
        import android.content.pm.PackageManager;
        import android.os.Bundle;
        import android.view.MotionEvent;
        import android.view.inputmethod.EditorInfo;
        import android.widget.Button;
        import android.widget.CheckBox;
        import android.widget.EditText;
        import android.widget.Toast;

        import androidx.annotation.NonNull;
        import androidx.appcompat.app.AppCompatActivity;
        import androidx.core.app.ActivityCompat;
        import androidx.core.content.ContextCompat;

        import io.plemons.inventoryapp_brettplemons.R;
        import io.plemons.inventoryapp_brettplemons.database.DatabaseHelper;

public class RegistrationActivity extends AppCompatActivity {
    private static final int SMS_PERMISSION_REQUEST_CODE = 123;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        dbHelper = new DatabaseHelper(this);

        // Initialize UI elements
        final EditText firstNameEditText = findViewById(R.id.first_name);
        final EditText lastNameEditText = findViewById(R.id.last_name);
        final EditText emailEditText = findViewById(R.id.email);
        final EditText passwordEditText = findViewById(R.id.password);
        final EditText confirmPasswordEditText = findViewById(R.id.confirm_password);
        final CheckBox agreeNotificationsCheckBox = findViewById(R.id.agree_notifications);
        final EditText phoneEditText = findViewById(R.id.phone);
        Button submitButton = findViewById(R.id.submit);

        // Hide keyboard when touching outside of input fields
        findViewById(R.id.registration_layout).setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_UP) {
                v.performClick();
            }
            hideKeyboard(this);
            return true;
        });

        // Hide keyboard when "done" is pressed on the keyboard
        confirmPasswordEditText.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                hideKeyboard(this);
                return true;
            }
            return false;
        });

        // Check for SMS permission if notifications are agreed to
        agreeNotificationsCheckBox.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked && ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_REQUEST_CODE);
            }
        });

        // Handle registration submission
        submitButton.setOnClickListener(v -> {
            // Validate and submit registration
            validateAndSubmitRegistration(firstNameEditText, lastNameEditText, emailEditText, passwordEditText, confirmPasswordEditText, agreeNotificationsCheckBox, phoneEditText);
        });
    }

    // Validate the registration form and submit if valid
    private void validateAndSubmitRegistration(EditText firstNameEditText, EditText lastNameEditText, EditText emailEditText, EditText passwordEditText, EditText confirmPasswordEditText, CheckBox agreeNotificationsCheckBox, EditText phoneEditText) {
        String firstName = firstNameEditText.getText().toString();
        String lastName = lastNameEditText.getText().toString();
        String email = emailEditText.getText().toString();
        String password = passwordEditText.getText().toString();
        String confirmPassword = confirmPasswordEditText.getText().toString();
        boolean smsConsent = agreeNotificationsCheckBox.isChecked();
        String phone = phoneEditText.getText().toString();

        if (phone.isEmpty()) {
            phoneEditText.setError("Phone number required.");
        } else {
            phoneEditText.setError(null);
        }

        if (firstName.isEmpty() || lastName.isEmpty() || email.isEmpty() || password.isEmpty()) {
            confirmPasswordEditText.setError("No fields may be empty.");
        }

        if (password.length() < 8) {
            // Show an error message for short passwords
            passwordEditText.setError("Password must be at least 8 characters long.");
        }


        if (dbHelper.emailExists(email)) {
            emailEditText.setError("An account with that email address already exists, try a different email or logging in.");
        } else {
            emailEditText.setError(null);
        }

        if (!password.equals(confirmPassword)) {
            // Show error message for mismatched passwords
            confirmPasswordEditText.setError("Passwords do not match.");
        } else {
            confirmPasswordEditText.setError(null);
        }

        if (!hasErrors()) {
            // Insert the new user
            if (dbHelper.insertUser(firstName, lastName, email, password, smsConsent, phone)) {
                Toast.makeText(this, "Registration successful!", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(this, "Registration failed. Please try again.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        // Handle permission result for SMS notifications
        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            handleSmsPermissionResult(grantResults);
        }
    }

    // Handle the result of the SMS permission request
    private void handleSmsPermissionResult(int[] grantResults) {
        CheckBox agreeNotificationsCheckBox = findViewById(R.id.agree_notifications);
        if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "SMS Notification enabled.", Toast.LENGTH_LONG).show();
            agreeNotificationsCheckBox.setChecked(true);
        } else {
            Toast.makeText(this, "Notifications will be disabled.", Toast.LENGTH_SHORT).show();
            agreeNotificationsCheckBox.setChecked(false);
        }
    }

    // Check if the form has any errors
    private boolean hasErrors() {
        EditText[] fields = {
                findViewById(R.id.first_name),
                findViewById(R.id.last_name),
                findViewById(R.id.email),
                findViewById(R.id.password),
                findViewById(R.id.confirm_password),
                findViewById(R.id.phone),
        };

        for (EditText field : fields) {
            if (field.getError() != null) {
                // At least one field in the form has a non-null error.
                return true;
            }
        }
        // No fields have a non-null error, the form can be submitted.
        return false;
    }
}

