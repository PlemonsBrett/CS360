package io.plemons.inventoryapp_brettplemons.activities;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

import io.plemons.inventoryapp_brettplemons.models.InventoryItem;
import io.plemons.inventoryapp_brettplemons.R;
import io.plemons.inventoryapp_brettplemons.models.User;
import io.plemons.inventoryapp_brettplemons.database.DatabaseHelper;

public class InventoryActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private User user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        dbHelper = new DatabaseHelper(this);
        SharedPreferences sharedPreferences = getSharedPreferences("InventoryApp", MODE_PRIVATE);

        setupToolbar();

        String email = sharedPreferences.getString("email", null);
        user = dbHelper.getUser(email);

        setupFloatingActionButton();

        createTable();
    }

    @Override
    protected void onResume() {
        super.onResume();
        createTable(); // Refresh the table when returning to the activity
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.action_settings) {
            startActivity(new Intent(this, SettingsActivity.class));
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void setupToolbar() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Get the colorOnPrimary attribute from the theme
        TypedValue typedValue = new TypedValue();
        getTheme().resolveAttribute(com.google.android.material.R.attr.colorOnPrimary, typedValue, true);

        // Change the title text color
        toolbar.setTitleTextColor(typedValue.data);
    }

    private void setupFloatingActionButton() {
        FloatingActionButton fab = findViewById(R.id.add_fab);
        fab.setOnClickListener(v -> {
            Intent intent = new Intent(this, AddItemActivity.class);
            intent.putExtra("email", user.getEmail());
            startActivity(intent);
        });
    }

    private void createTable() {
        TableLayout tableLayout = findViewById(R.id.inventory_table);
        tableLayout.removeAllViews(); // Clear previous rows

        addHeaderRow(tableLayout);

        List<InventoryItem> items = dbHelper.getAllItems();
        if (items.isEmpty()) {
            handleEmptyState(tableLayout);
        } else {
            addDataRows(tableLayout, items);
        }
    }

    private void addHeaderRow(@NonNull TableLayout tableLayout) {
        TableRow headerRow = new TableRow(this);
        headerRow.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT, TableRow.LayoutParams.WRAP_CONTENT));
        addTextCell(headerRow, "ID", true);
        addTextCell(headerRow, "Name", true);
        addTextCell(headerRow, "Description", true);
        addTextCell(headerRow, "Quantity", true);
        addTextCell(headerRow, "Unit", true);
        addTextCell(headerRow, "Location", true);
        addTextCell(headerRow, "LastUpdated", true);
        addTextCell(headerRow, "Edit?", true);
        tableLayout.addView(headerRow);

        // Add divider between header and data
        View divider = new View(this);
        divider.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT, 1));
        divider.setBackgroundColor(Color.BLACK);
        tableLayout.addView(divider);
    }

    private void handleEmptyState(@NonNull TableLayout tableLayout) {
        // Handle empty state
        TextView emptyView = new TextView(this);
        emptyView.setText(R.string.no_items_available);
        emptyView.setGravity(Gravity.CENTER);
        tableLayout.addView(emptyView);
    }

    private void addDataRows(TableLayout tableLayout, @NonNull List<InventoryItem> items) {
        // Add data rows
        for (InventoryItem item : items) {
            TableRow row = new TableRow(this);
            row.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT, TableRow.LayoutParams.WRAP_CONTENT));
            addTextCell(row, item.getItemId(), false);
            addTextCell(row, item.getItemName(), false);
            addTextCell(row, item.getItemDescription(), false);
            addTextCell(row, String.valueOf(item.getQuantity()), false);
            addTextCell(row, item.getUnit(), false);
            addTextCell(row, item.getLocation(), false);
            addTextCell(row, item.getLastUpdated(), false);
            addButtonCell(row, item);
            tableLayout.addView(row);
        }
    }

    private void addTextCell(@NonNull TableRow row, String text, boolean isHeader) {
        TextView cell = new TextView(this);
        cell.setText(text);
        styleCell(cell, isHeader);
        row.addView(cell);
    }

    private void addButtonCell(@NonNull TableRow row, InventoryItem item) {
        Button editButton = new Button(this);
        editButton.setText("Edit");
        editButton.setBackground(null); // Remove default button background
        editButton.setOnClickListener(v -> {
            // Navigate to EditItemActivity with the item's data
            Intent intent = new Intent(this, EditItemActivity.class);
            intent.putExtra("itemId", item.getItemId());
            intent.putExtra("email", user.getEmail());
            startActivity(intent);
        });
        styleCell(editButton, false);
        row.addView(editButton);
    }

    private void styleCell(@NonNull TextView cell, boolean isHeader) {
        int padding = isHeader ? 20 : 10; // More padding for headers
        cell.setPadding(padding, padding, padding, padding);
        int height = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 40, getResources().getDisplayMetrics()); // 40dp height
        TableRow.LayoutParams params = new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT, height);
        cell.setLayoutParams(params);
        cell.setGravity(Gravity.CENTER); // Center text
        cell.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18); // Increase text size
        if (isHeader) {
            cell.setTypeface(null, Typeface.BOLD); // Bold headers
        }
        cell.setBackgroundResource(R.drawable.cell_shape); // Apply cell background
    }
}
