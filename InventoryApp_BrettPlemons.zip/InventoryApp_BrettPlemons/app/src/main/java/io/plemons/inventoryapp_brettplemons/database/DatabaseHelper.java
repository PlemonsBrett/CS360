package io.plemons.inventoryapp_brettplemons.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import io.plemons.inventoryapp_brettplemons.models.InventoryItem;
import io.plemons.inventoryapp_brettplemons.models.User;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "inventory";
    private static final int DATABASE_VERSION = 1;

    // User Table
    private static final String CREATE_TABLE_USER = "CREATE TABLE IF NOT EXISTS User (" +
            "id INTEGER PRIMARY KEY AUTOINCREMENT DEFAULT(0) NOT NULL," +
            "FirstName TEXT," +
            "LastName TEXT," +
            "Email TEXT UNIQUE NOT NULL," +
            "Password TEXT NOT NULL," +
            "SmsConsent BOOL DEFAULT(0)," +
            "Phone TEXT NOT NULL" +
            ");";

    // Item Table
    private static final String CREATE_TABLE_ITEM = "CREATE TABLE IF NOT EXISTS Item(" +
            "id INTEGER PRIMARY KEY AUTOINCREMENT DEFAULT(0) NOT NULL," +
            "ItemId INTEGER UNIQUE NOT NULL," +
            "Name TEXT NOT NULL," +
            "Description TEXT," +
            "Quantity TEXT DEFAULT(0) NOT NULL," +
            "Unit TEXT NOT NULL," +
            "Location TEXT," +
            "CreatedBy INTEGER NOT NULL," +
            "LastUpdated TEXT," +
            "LastUpdatedBy INTEGER NOT NULL," +
            "FOREIGN KEY (LastUpdatedBy) REFERENCES User(id)," +
            "FOREIGN KEY (CreatedBy) REFERENCES User(id)" +
            ");";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_USER);
        db.execSQL(CREATE_TABLE_ITEM);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Handle database upgrade if needed
    }

    // User Methods
    public boolean insertUser(
            String firstName, String lastName, String email, String password, boolean smsConsent,
            String phone
    ) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("FirstName", firstName);
        values.put("LastName", lastName);
        values.put("Email", email);
        values.put("Password", password);
        values.put("Phone", phone);
        values.put("SmsConsent", smsConsent ? 1 : 0); // Convert boolean to integer
        long result = db.insert("User", null, values);
        return result != -1; // Return true if insert was successful
    }

    public User getUser(String email) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("SELECT id, FirstName, LastName, Email, Phone, SmsConsent FROM User WHERE Email = ?", new String[]{email});

        if (cursor.moveToFirst()) {
            int idIndex = cursor.getColumnIndexOrThrow("id");
            int firstNameIndex = cursor.getColumnIndexOrThrow("FirstName");
            int lastNameIndex = cursor.getColumnIndexOrThrow("LastName");
            int emailIndex = cursor.getColumnIndexOrThrow("Email");
            int consentIndex = cursor.getColumnIndexOrThrow("SmsConsent");
            int phoneIndex = cursor.getColumnIndexOrThrow("Phone");

            User user = new User(
                    cursor.getInt(idIndex),
                    cursor.getString(firstNameIndex),
                    cursor.getString(lastNameIndex),
                    cursor.getString(emailIndex),
                    cursor.getInt(consentIndex) == 1,
                    cursor.getString(phoneIndex)
            );
            cursor.close();
            return user;
        }
        cursor.close();
        return null; // Return null if the user is not found
    }

    public Boolean deleteUser(String id) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rowsAffected = db.delete("User", "id = ?", new String[]{String.valueOf(id)});
        return rowsAffected > 0;
    }

    public Boolean updateUser(User user) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("FirstName", user.getFirstName());
        values.put("LastName", user.getLastName());
        values.put("Email", user.getEmail());
        values.put("SmsConsent", user.getSmsConsent() ? 1 : 0); // Convert boolean to integer
        values.put("Phone", user.getPhone());

        // Update the row in the database where the id matches
        int result = db.update("User", values, "id = ?", new String[]{String.valueOf(user.getId())});

        return result != -1; // Return true if update was successful
    }

    // User Validators
    public Boolean validateUser(String email, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT Password FROM User WHERE Email = ?", new String[]{email});

        if (cursor.moveToFirst()) {
            Log.d("DatabaseHelper", "Found at least 1 value in db");
            if (Objects.equals(cursor.getString(0), password)) {
                return true;
            }
            cursor.close();
        }

        cursor.close();
        return false;
    }

    public boolean emailExists(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT 1 FROM User WHERE Email = ?", new String[]{email});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    // Item Methods
    public List<InventoryItem> getAllItems() {
        List<InventoryItem> items = new ArrayList<>();

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM Item", null);

        int itemIdIndex = cursor.getColumnIndexOrThrow("ItemId");
        int itemNameIndex = cursor.getColumnIndexOrThrow("Name");
        int itemDescriptionIndex = cursor.getColumnIndexOrThrow("Description");
        int quantityIndex = cursor.getColumnIndexOrThrow("Quantity");
        int unitIndex = cursor.getColumnIndexOrThrow("Unit");
        int locationIndex = cursor.getColumnIndexOrThrow("Location");
        int createdByIndex = cursor.getColumnIndexOrThrow("CreatedBy");
        int lastUpdatedIndex = cursor.getColumnIndexOrThrow("LastUpdated");
        int lastUpdatedByIndex = cursor.getColumnIndexOrThrow("LastUpdatedBy");

        if (cursor.moveToFirst()) {
            do {
                String itemId = cursor.getString(itemIdIndex);
                String itemName = cursor.getString(itemNameIndex);
                String itemDescription = cursor.getString(itemDescriptionIndex);
                int quantity = cursor.getInt(quantityIndex);
                String unit = cursor.getString(unitIndex);
                String location = cursor.getString(locationIndex);
                int createdBy = cursor.getInt(createdByIndex);
                String lastUpdated = cursor.getString(lastUpdatedIndex);
                int lastUpdatedBy = cursor.getInt(lastUpdatedByIndex);
                // Add other fields as needed

                InventoryItem item = new InventoryItem(
                        itemId,
                        itemName,
                        itemDescription,
                        quantity,
                        unit,
                        location,
                        createdBy,
                        lastUpdated,
                        lastUpdatedBy
                );
                items.add(item);
            } while (cursor.moveToNext());
        }

        cursor.close();
        return items;
    }

    public void insertItem(InventoryItem item) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put("ItemId", item.getItemId());
        values.put("Name", item.getItemName());
        values.put("Quantity", item.getQuantity());
        values.put("Description", item.getItemDescription());
        values.put("Unit", item.getUnit());
        values.put("Location", item.getLocation());
        values.put("CreatedBy", item.getCreatedBy());
        values.put("LastUpdatedBy", item.getLastUpdatedBy());
        values.put("LastUpdated", item.getLastUpdated());

        db.insert("Item", null, values);
    }

    public void updateItem(InventoryItem item) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("Name", item.getItemName());
        values.put("Description", item.getItemDescription());
        values.put("Quantity", item.getQuantity());
        values.put("Unit", item.getUnit());
        values.put("Location", item.getLocation());
        values.put("LastUpdatedBy", item.getLastUpdatedBy());
        values.put("LastUpdated", item.getLastUpdated());

        // Update the row in the database where the ItemId matches
        db.update("Item", values, "ItemId = ?", new String[]{String.valueOf(item.getItemId())});
    }

    public void deleteItem(String itemId) {
        SQLiteDatabase db = this.getWritableDatabase();

        // Delete the row from the database where the ItemId matches
        db.delete("Item", "ItemId = ?", new String[]{itemId});
    }

    // Item Validators
    public boolean itemExists(String itemId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT 1 FROM Item WHERE ItemID = ?", new String[]{itemId});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    public InventoryItem getItem(String id) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM Item WHERE ItemID = ?", new String[]{id});

        if (cursor.moveToFirst()) {
            int itemIdIndex = cursor.getColumnIndexOrThrow("ItemId");
            int itemNameIndex = cursor.getColumnIndexOrThrow("Name");
            int itemDescriptionIndex = cursor.getColumnIndexOrThrow("Description");
            int quantityIndex = cursor.getColumnIndexOrThrow("Quantity");
            int unitIndex = cursor.getColumnIndexOrThrow("Unit");
            int locationIndex = cursor.getColumnIndexOrThrow("Location");
            int createdByIndex = cursor.getColumnIndexOrThrow("CreatedBy");
            int lastUpdatedIndex = cursor.getColumnIndexOrThrow("LastUpdated");
            int lastUpdatedByIndex = cursor.getColumnIndexOrThrow("LastUpdatedBy");

            String itemId = cursor.getString(itemIdIndex);
            String itemName = cursor.getString(itemNameIndex);
            String itemDescription = cursor.getString(itemDescriptionIndex);
            int quantity = cursor.getInt(quantityIndex);
            String unit = cursor.getString(unitIndex);
            String location = cursor.getString(locationIndex);
            int createdBy = cursor.getInt(createdByIndex);
            String lastUpdated = cursor.getString(lastUpdatedIndex);
            int lastUpdatedBy = cursor.getInt(lastUpdatedByIndex);

            InventoryItem item = new InventoryItem(
                    itemId,
                    itemName,
                    itemDescription,
                    quantity,
                    unit,
                    location,
                    createdBy,
                    lastUpdated,
                    lastUpdatedBy
            );

            cursor.close();
            return item;
        } else {
            cursor.close();
            return null; // Return null if no item found
        }
    }
}
