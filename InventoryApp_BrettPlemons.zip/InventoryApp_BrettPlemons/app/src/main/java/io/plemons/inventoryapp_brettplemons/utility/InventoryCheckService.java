package io.plemons.inventoryapp_brettplemons.utility;

import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.IBinder;

import androidx.annotation.Nullable;

import java.util.List;

import io.plemons.inventoryapp_brettplemons.database.DatabaseHelper;
import io.plemons.inventoryapp_brettplemons.models.InventoryItem;
import io.plemons.inventoryapp_brettplemons.models.User;

public class InventoryCheckService extends Service {

    private static final int CHECK_INTERVAL = 30000; // 30 seconds
    private Handler handler;
    private Runnable runnable;
    private DatabaseHelper dbHelper;
    private User user;

    @Override
    public void onCreate() {
        super.onCreate();

        dbHelper = new DatabaseHelper(this);

        SharedPreferences sharedPreferences = getSharedPreferences("InventoryApp", MODE_PRIVATE);
        String email = sharedPreferences.getString("email", null);
        user = dbHelper.getUser(email);

        handler = new Handler();
        runnable = new Runnable() {
            @Override
            public void run() {
                checkInventory();
                handler.postDelayed(this, CHECK_INTERVAL);
            }
        };
        handler.post(runnable);
    }

    private void checkInventory() {
        dbHelper = new DatabaseHelper(this);
        List<InventoryItem> items = dbHelper.getAllItems();

        for (InventoryItem item : items) {
            if (item.getQuantity() < 5) {
                // Send SMS alert
                String phoneNumber = user.getPhone(); // Retrieve the user's phone number
                String message = "Low inventory alert for item: " + item.getItemName();
                SmsUtil.sendSms(this, phoneNumber, message);
            }
        }
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        handler.removeCallbacks(runnable);
    }
}

