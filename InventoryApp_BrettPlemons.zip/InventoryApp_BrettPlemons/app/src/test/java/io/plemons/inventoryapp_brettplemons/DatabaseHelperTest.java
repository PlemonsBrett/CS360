package io.plemons.inventoryapp_brettplemons;

import android.content.Context;

import androidx.test.core.app.ApplicationProvider;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;

import io.plemons.inventoryapp_brettplemons.database.DatabaseHelper;
import io.plemons.inventoryapp_brettplemons.models.InventoryItem;
import io.plemons.inventoryapp_brettplemons.models.User;

import static org.junit.Assert.*;

import java.util.List;

@RunWith(RobolectricTestRunner.class)
public class DatabaseHelperTest {

    private DatabaseHelper dbHelper;

    @Before
    public void setUp() {
        Context context = ApplicationProvider.getApplicationContext();
        dbHelper = new DatabaseHelper(context);
    }

    @Test
    public void testInsertUser() {
        boolean result = dbHelper.insertUser("John", "Doe", "john.doe@example.com", "password", false, "1234567890");
        assertTrue(result);
    }

    @Test
    public void testGetUser() {
        dbHelper.insertUser("John", "Doe", "john.doe@example.com", "password", false, "1234567890");
        User user = dbHelper.getUser("john.doe@example.com");
        assertNotNull(user);
        assertEquals("John", user.getFirstName());
        assertEquals("Doe", user.getLastName());
    }

    @Test
    public void testUpdateUser() {
        dbHelper.insertUser("John", "Doe", "john.doe@example.com", "password", false, "1234567890");
        User user = dbHelper.getUser("john.doe@example.com");
        user.setFirstName("Jane");
        boolean result = dbHelper.updateUser(user);
        assertTrue(result);
        user = dbHelper.getUser("john.doe@example.com");
        assertEquals("Jane", user.getFirstName());
    }

    @Test
    public void testDeleteUser() {
        dbHelper.insertUser("John", "Doe", "john.doe@example.com", "password", false, "1234567890");
        User user = dbHelper.getUser("john.doe@example.com");
        boolean result = dbHelper.deleteUser(String.valueOf(user.getId()));
        assertTrue(result);
        user = dbHelper.getUser("john.doe@example.com");
        assertNull(user);
    }

    @Test
    public void testValidateUser() {
        dbHelper.insertUser("John", "Doe", "john@example.com", "password", false, "1234567890");
        assertTrue(dbHelper.validateUser("john@example.com", "password"));
        assertFalse(dbHelper.validateUser("john@example.com", "wrongpassword"));
    }

    @Test
    public void testEmailExists() {
        dbHelper.insertUser("John", "Doe", "john@example.com", "password", false, "1234567890");
        assertTrue(dbHelper.emailExists("john@example.com"));
        assertFalse(dbHelper.emailExists("jane@example.com"));
    }

    @Test
    public void testInsertItem() {
        InventoryItem item = new InventoryItem("1", "Item1", "Description", 5, "kg", "Location", 1, "LastUpdated", 1);
        dbHelper.insertItem(item);
        assertNotNull(dbHelper.getItem("1"));
    }

    @Test
    public void testUpdateItem() {
        InventoryItem item = new InventoryItem("1", "Item1", "Description", 5, "kg", "Location", 1, "LastUpdated", 1);
        dbHelper.insertItem(item);
        item.setItemName("UpdatedItem");
        dbHelper.updateItem(item);
        assertEquals("UpdatedItem", dbHelper.getItem("1").getItemName());
    }

    @Test
    public void testDeleteItem() {
        InventoryItem item = new InventoryItem("1", "Item1", "Description", 5, "kg", "Location", 1, "LastUpdated", 1);
        dbHelper.insertItem(item);
        dbHelper.deleteItem("1");
        assertNull(dbHelper.getItem("1"));
    }

    @Test
    public void testItemExists() {
        InventoryItem item = new InventoryItem("1", "Item1", "Description", 5, "kg", "Location", 1, "LastUpdated", 1);
        dbHelper.insertItem(item);
        assertTrue(dbHelper.itemExists("1"));
        assertFalse(dbHelper.itemExists("2"));
    }

    @Test
    public void testGetItem() {
        InventoryItem item = new InventoryItem("1", "Item1", "Description", 5, "kg", "Location", 1, "LastUpdated", 1);
        dbHelper.insertItem(item);
        InventoryItem retrievedItem = dbHelper.getItem("1");
        assertEquals(item.getItemId(), retrievedItem.getItemId());
        assertEquals(item.getItemName(), retrievedItem.getItemName());
    }

    @Test
    public void testGetAllItems() {
        InventoryItem item1 = new InventoryItem("1", "Item1", "Description", 5, "kg", "Location", 1, "LastUpdated", 1);
        InventoryItem item2 = new InventoryItem("2", "Item2", "Description", 10, "kg", "Location", 1, "LastUpdated", 1);
        dbHelper.insertItem(item1);
        dbHelper.insertItem(item2);
        List<InventoryItem> items = dbHelper.getAllItems();
        assertEquals(2, items.size());
    }
}
